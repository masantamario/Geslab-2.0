package geslab.database.user;

public class Prudencia {
	private String frase;
	private String consejo;
	
	public Prudencia(String frase, String consejo) {
		this.frase = frase;
		this.consejo = consejo;
	}

	public String getFrase() {
		return frase;
	}

	public String getConsejo() {
		return consejo;
	}
	
}
